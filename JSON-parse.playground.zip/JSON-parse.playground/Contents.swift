import Foundation

enum CardsName: String {
    case opt = "Opt"
    case blackLotus = "Black%20Lotus"
}

struct Cards: Decodable {
    let cards: [Card]
}

struct Card: Decodable {
    let name: String?
    let manaCost: String?
    let cmc: Double?
    let type: String?
    let cardSet, setName, text: String?
    let flavor: String?
    let artist, number: String?
    let power, toughness: String?
}

func getData(urlRequest: String) {
    let urlRequest = URL(string: urlRequest)
    let configuration = URLSessionConfiguration.default
    configuration.allowsCellularAccess = true
    guard let url = urlRequest else { return }
    URLSession.shared.dataTask(with: url) { data, response, error in
        if error != nil {
            print("error: \(error?.localizedDescription ?? "")")
        } else if let response = response as? HTTPURLResponse, response.statusCode == 200 {
            print("response: \(response.statusCode)\n")
            
            guard let data = data else  { return }
            do {
                let result = try JSONDecoder().decode(Cards.self, from: data)
                print("""
                      Card name: \(result.cards.first?.name ?? "")
                      Mana cost: \(result.cards.first?.manaCost ?? "")
                      Cmc: \(result.cards.first?.cmc ?? 0)
                      Type: \(result.cards.first?.type ?? "")
                      Card set: \(result.cards.first?.cardSet ?? "")
                      SetName: \(result.cards.first?.setName ?? "")
                      Text: \(result.cards.first?.text ?? "")
                      Flavor: \(result.cards.first?.flavor ?? "")
                      Artist: \(result.cards.first?.artist ?? "")
                      Number: \(result.cards.first?.number ?? "")
                      Power: \(result.cards.first?.power ?? "")
                      Toughness: \(result.cards.first?.toughness ?? "")\n
                      """)
            } catch {
                print(error)
            }
        }
    }.resume()
}

func makeUrl (cardName: CardsName) -> String {
    let url = "https://api.magicthegathering.io/v1/cards?name=%22\(cardName.rawValue)%22"
    return url
}

getData(urlRequest: makeUrl(cardName: .opt))
getData(urlRequest: makeUrl(cardName: .blackLotus))
